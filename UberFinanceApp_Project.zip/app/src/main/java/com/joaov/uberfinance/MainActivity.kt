
package com.joaov.uberfinance

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val faturamento = findViewById<EditText>(R.id.etFaturamento)
        val km = findViewById<EditText>(R.id.etKm)
        val media = findViewById<EditText>(R.id.etMedia)
        val preco = findViewById<EditText>(R.id.etPreco)
        val btn = findViewById<Button>(R.id.btnCalcular)
        val resultado = findViewById<TextView>(R.id.tvResultado)

        btn.setOnClickListener {

            val f = faturamento.text.toString().toDoubleOrNull() ?: 0.0
            val k = km.text.toString().toDoubleOrNull() ?: 0.0
            val m = media.text.toString().toDoubleOrNull() ?: 1.0
            val p = preco.text.toString().toDoubleOrNull() ?: 0.0

            val litros = k / m
            val combustivel = litros * p
            val lucro = f - combustivel

            resultado.text = String.format(
                "Litros: %.2f\nCombustível: R$ %.2f\nLucro: R$ %.2f",
                litros, combustivel, lucro
            )
        }
    }
}
